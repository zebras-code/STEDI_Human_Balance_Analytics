# Examples Only

These solution files are examples only. Your files will need to reflect your own table names.

Your script will help you remember the query you used to join the tables.

